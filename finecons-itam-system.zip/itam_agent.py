#!/usr/bin/env python3
"""
IT Asset Management Agent - Ready for Deployment
Collects system information and reports to central dashboard
"""

import json
import platform
import socket
import subprocess
import sys
import time
import requests
from datetime import datetime

# Configuration - Your Dashboard URL
DASHBOARD_URL = "https://4d454db1-bf57-45a3-8c22-f54b8eab2982-00-3tktq9yl62ggy.riker.replit.dev/api/device-update"
AGENT_VERSION = "1.0.0"
REPORT_INTERVAL = 60  # Report every 60 seconds for real-time updates

def get_hostname():
    """Get the computer's hostname"""
    return socket.gethostname()

def get_operating_system():
    """Get detailed OS information"""
    return f"{platform.system()} {platform.release()} {platform.version()}"

def get_ip_address():
    """Get the local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
        s.close()
        return ip_address
    except Exception:
        return "Unknown"

def get_installed_software():
    """Get installed software based on operating system"""
    os_name = platform.system().lower()
    software_list = []
    
    if os_name == "windows":
        try:
            import winreg
            registry_paths = [
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
            ]
            
            for path in registry_paths:
                try:
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        try:
                            subkey_name = winreg.EnumKey(key, i)
                            subkey = winreg.OpenKey(key, subkey_name)
                            try:
                                name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                                if name and len(name) > 2:
                                    software_list.append(name)
                            except FileNotFoundError:
                                pass
                            winreg.CloseKey(subkey)
                        except OSError:
                            continue
                    winreg.CloseKey(key)
                except Exception:
                    continue
        except ImportError:
            software_list = ["Microsoft Office", "Google Chrome", "Windows Security"]
            
    elif os_name == "linux":
        try:
            commands = [
                ["dpkg", "--get-selections"],
                ["rpm", "-qa"],
                ["pacman", "-Q"]
            ]
            
            for cmd in commands:
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                    if result.returncode == 0:
                        lines = result.stdout.strip().split('\n')
                        for line in lines[:30]:
                            if line.strip():
                                pkg_name = line.split()[0] if line.split() else line
                                software_list.append(pkg_name)
                        break
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    continue
        except Exception:
            software_list = ["Firefox", "LibreOffice", "Git", "Python3"]
            
    elif os_name == "darwin":  # macOS
        try:
            result = subprocess.run(
                ["system_profiler", "SPApplicationsDataType", "-json"],
                capture_output=True, text=True, timeout=30
            )
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                applications = data.get('SPApplicationsDataType', [])
                
                for app in applications[:30]:
                    name = app.get('_name', '')
                    if name:
                        software_list.append(name)
        except Exception:
            software_list = ["Safari", "Chrome", "Terminal", "Finder"]
    
    return software_list[:30]  # Limit to 30 programs

def get_system_uptime():
    """Get system uptime information"""
    try:
        if platform.system() == "Windows":
            import ctypes
            uptime_ms = ctypes.windll.kernel32.GetTickCount64()
            uptime_hours = uptime_ms // (1000 * 60 * 60)
            return f"{uptime_hours} hours"
        else:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
                uptime_hours = int(uptime_seconds // 3600)
                return f"{uptime_hours} hours"
    except:
        return "Unknown"

def collect_system_info():
    """Collect all system information"""
    return {
        "deviceName": get_hostname(),
        "operatingSystem": get_operating_system(),
        "installedSoftware": get_installed_software(),
        "ipAddress": get_ip_address(),
        "location": "Agent-Reported",
        "agentVersion": AGENT_VERSION,
        "reportTime": datetime.now().isoformat(),
        "systemUptime": get_system_uptime()
    }

def send_report(data):
    """Send system information to the dashboard"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': f'ITAM-Agent/{AGENT_VERSION}'
        }
        
        response = requests.post(
            DASHBOARD_URL,
            json=data,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Report sent - Threats: {result.get('detectedThreats', 0)}")
            return True
        else:
            print(f"✗ Failed: {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"✗ Network error: {e}")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def main():
    """Main agent function"""
    print(f"🔍 ITAM Agent v{AGENT_VERSION} Starting...")
    print(f"📊 Dashboard: ...{DASHBOARD_URL[-30:]}")
    print(f"⏱️  Update interval: {REPORT_INTERVAL} seconds")
    print("🔄 Starting real-time monitoring...\n")
    
    while True:
        try:
            timestamp = datetime.now().strftime('%H:%M:%S')
            print(f"[{timestamp}] Collecting system data...", end=" ")
            
            # Collect system data
            system_info = collect_system_info()
            print(f"({len(system_info['installedSoftware'])} programs)", end=" ")
            
            # Send report
            success = send_report(system_info)
            
            if not success:
                print("Retrying in 30 seconds...")
                time.sleep(30)
                continue
                
            # Wait before next report
            time.sleep(REPORT_INTERVAL)
            
        except KeyboardInterrupt:
            print("\n🛑 Agent stopped by user")
            break
        except Exception as e:
            print(f"\n⚠️  Error: {e}")
            print("Retrying in 60 seconds...")
            time.sleep(60)

if __name__ == "__main__":
    main()